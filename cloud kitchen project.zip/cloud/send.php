<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

function sendOrderEmail($orderSummary, $address, $phone, $total) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'yuvarajaravi2004@gmail.com';  // replace with your email
        $mail->Password = 'mpwpfmllroiehgfb';            // replace with your email app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        // Recipient and sender
        $mail->setFrom('yuvarajaravi2004@gmail.com', 'Cloud Kitchen');
        $mail->addAddress('yuvarajar2004@gmail.com');  // Default recipient

        // Email content
        $mail->isHTML(true);
        $mail->Subject = "New Order";
        
        // Compose the order summary message
        $message = "<h3>Order Summary</h3>";
        $message .= "<p><strong>Address:</strong> $address</p>";
        $message .= "<p><strong>Phone Number:</strong> $phone</p>";
        $message .= "<table border='1' cellpadding='10'><tr><th>Item</th><th>Quantity</th><th>Subtotal</th></tr>";

        foreach ($orderSummary as $item) {
            $message .= "<tr><td>{$item['name']}</td><td>{$item['quantity']}</td><td>₹{$item['subtotal']}</td></tr>";
        }

        $message .= "<tr><td colspan='2'><strong>Total</strong></td><td><strong>₹$total</strong></td></tr>";
        $message .= "</table>";

        $mail->Body = $message;

        $mail->send();
    } catch (Exception $e) {
        echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
    }
}
