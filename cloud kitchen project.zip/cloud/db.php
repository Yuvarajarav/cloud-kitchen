<?php
$servername = "localhost";
$username = "root";
$password = "Kalaivani2807@";
$dbname = "cloud_kitchen";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
