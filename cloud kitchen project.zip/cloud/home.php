<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <style>
        /* Modern styling */
        body { background-image: url('pic1.jpg'); background-size: cover; font-family: Arial, sans-serif; }
        .home-container { width: 90%; max-width: 600px; margin: auto; padding: 20px; background-color: rgba(255, 255, 255, 0.85); border-radius: 8px; text-align: center; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2); }
        h2 { color: #333; }
        .nav-links a { padding: 15px 25px; background-color: #4CAF50; color: white; border-radius: 5px; text-decoration: none; font-size: 18px; margin: 10px; display: inline-block; }
        .nav-links a:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <div class="home-container">
        <h2>Welcome to the Food Menu</h2>
        <div class="nav-links">
            <a href="menu.php">View Menu</a>
            <a href="cart.php">Cart</a>
            <a href="signout.php">Sign Out</a>
        </div>
    </div>
</body>
</html>
