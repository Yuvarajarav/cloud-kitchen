<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $mobile_number = $_POST['mobile_number'];

    $conn->query("INSERT INTO users (username, password, mobile_number) VALUES ('$username', '$password', '$mobile_number')");
    header("Location: login.php");
}
?>
