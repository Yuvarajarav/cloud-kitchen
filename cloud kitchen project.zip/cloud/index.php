<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Cloud Kitchen</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url('pic3.webp');
            background-size:cover; /* Replace with your image path */
            background-size: cover;
            background-position: center;
            color: #fff;
        }
        .index-container {
            text-align: center;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        .index-container h1 {
            margin-bottom: 20px;
            font-size: 2em;
        }
        .button {
            padding: 15px 25px;
            background-color: #4CAF50;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="index-container">
        <h1>Welcome to Cloud Kitchen</h1>
        <a href="login.php" class="button">Enter into Kitchen</a>
    </div>
</body>
</html>
