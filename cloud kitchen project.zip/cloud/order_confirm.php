<?php
session_start();
require 'send.php';

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_SESSION['cart'])) {
    header("Location: menu.php");
    exit;
}

// Retrieve order details
$address = $_POST['address'];
$phone = $_POST['phone'];
$total = 0;
$order_summary = [];

// Menu items (for simplicity, hardcoded here; typically from a database)
$menu_items = [
    1 => ['name' => 'Dosa', 'price' => 50],
    2 => ['name' => 'Idli', 'price' => 30],
    3 => ['name' => 'Pongal', 'price' => 30],
    4 => ['name' => 'Poori', 'price' => 40],
    5 => ['name' => 'Vada', 'price' => 10],
    6 => ['name' => 'Meals', 'price' => 100]
];

foreach ($_SESSION['cart'] as $item_id => $quantity) {
    $item = $menu_items[$item_id];
    $subtotal = $item['price'] * $quantity;
    $total += $subtotal;
    $order_summary[] = [
        'name' => $item['name'],
        'quantity' => $quantity,
        'subtotal' => $subtotal
    ];
}

// Send the order email
sendOrderEmail($order_summary, $address, $phone, $total);

// Clear the cart
unset($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 0; }
        .container { width: 60%; margin: auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #ddd; }
        .total { font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Order Confirmed!</h2>
        <p>Thank you for your order. Here is your order summary:</p>

        <h3>Delivery Details</h3>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($address); ?></p>
        <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($phone); ?></p>

        <table>
            <tr><th>Item</th><th>Quantity</th><th>Subtotal</th></tr>
            <?php foreach ($order_summary as $item): ?>
                <tr>
                    <td><?php echo $item['name']; ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>₹<?php echo $item['subtotal']; ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="2" class="total">Total</td>
                <td class="total">₹<?php echo $total; ?></td>
            </tr>
        </table>
    </div>
</body>
</html>