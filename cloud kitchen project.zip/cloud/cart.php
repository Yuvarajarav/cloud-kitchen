<?php
session_start();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty.";
    exit;
}

// Menu items (for simplicity, hardcoded here; typically from a database)
$menu_items = [
    1 => ['name' => 'Dosa', 'price' => 50],
    2 => ['name' => 'Idli', 'price' => 30],
    3 => ['name' => 'Pongal', 'price' => 30],
    4 => ['name' => 'Poori', 'price' => 40],
    5 => ['name' => 'Vada', 'price' => 10],
    6 => ['name' => 'Meals', 'price' => 100]
];

// Calculate the total
$total = 0;
$order_summary = [];

foreach ($_SESSION['cart'] as $item_id => $quantity) {
    $item = $menu_items[$item_id];
    $subtotal = $item['price'] * $quantity;
    $total += $subtotal;
    $order_summary[] = [
        'name' => $item['name'],
        'quantity' => $quantity,
        'subtotal' => $subtotal
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <style>
        body { background-image: url('pic5.jpg'); background-size: cover; font-family: Arial, sans-serif; text-align: center; margin: 0; }
        .container { width: 60%; margin: auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #ddd; }
        .total { font-weight: bold; }
        .button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Cart</h2>
        <table>
            <tr><th>Item</th><th>Quantity</th><th>Subtotal</th></tr>
            <?php foreach ($order_summary as $item): ?>
                <tr>
                    <td><?php echo $item['name']; ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>₹<?php echo $item['subtotal']; ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="2" class="total">Total</td>
                <td class="total">₹<?php echo $total; ?></td>
            </tr>
        </table>

        <form method="post" action="order_confirm.php">
            <h3>Delivery Address</h3>
            <textarea name="address" required placeholder="Enter your delivery address here" rows="4" style="width: 100%;"></textarea>
            <br><br>
            <label for="phone">Phone Number:</label>
            <input type="tel" name="phone" required placeholder="Enter your phone number" style="width: 100%; padding: 10px; margin-top: 10px;" pattern="[0-9]{10}">
            <br><br>
            <button type="submit" class="button">Confirm Order</button>
        </form>
    </div>
</body>
</html>