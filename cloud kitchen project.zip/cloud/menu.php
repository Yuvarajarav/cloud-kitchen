<?php
// Assume predefined items in PHP array
$menu_items = [
    ['id' => 1, 'name' => 'Dosa', 'price' => 50],
    ['id' => 2, 'name' => 'Idli', 'price' => 30],
    ['id' => 3, 'name' => 'Pongal', 'price' => 30],
    ['id' => 4, 'name' => 'Poori', 'price' => 40],
    ['id' => 5, 'name' => 'Vada', 'price' => 10],
    ['id' => 6, 'name' => 'Meals', 'price' => 100]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu</title>
    <style>
        /* Reset and basic styles */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background-image: url('pic4.jpg'); background-size:cover;
            display: flex; justify-content: center; align-items: center; min-height: 100vh; font-family: Arial, sans-serif; background-color: #f5f5f5; }

        /* Container */
        .menu-container {
            width: 100%;
            max-width: 500px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            text-align: center;
        }

        /* Title */
        h2 { margin-bottom: 20px; color: #333; }

        /* Menu items */
        .menu-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .menu-item:last-child {
            border-bottom: none;
        }

        /* Input field for quantity */
        input[type="number"] {
            width: 50px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
        }

        /* Add to Cart button */
        input[type="submit"] {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="menu-container">
        <h2>Menu</h2>
        <form method="post" action="add_to_cart.php">
            <?php foreach ($menu_items as $item) : ?>
                <div class="menu-item">
                    <span><?php echo $item['name']; ?> - ₹<?php echo $item['price']; ?></span>
                    <label>
                        Quantity: <input type="number" name="quantity[<?php echo $item['id']; ?>]" min="0">
                    </label>
                </div>
            <?php endforeach; ?>
            <input type="submit" value="Add to Cart">
        </form>
    </div>
</body>
</html>