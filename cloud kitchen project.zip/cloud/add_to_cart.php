<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['quantity'] as $item_id => $quantity) {
        if ($quantity > 0) {
            $_SESSION['cart'][$item_id] = $quantity;
        }
    }
    header("Location: cart.php");
    exit();
}
?>
